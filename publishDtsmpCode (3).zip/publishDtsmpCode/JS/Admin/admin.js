﻿$(document).ready(function () {
    fn_runningdata();
    $("#txtrunningSearch").keypress(function (e) {

        if (e.which == 13) {
            fn_runningdata($(this).val());
            return false;
        }
    });

    $("#txtobsoleteSearch").keypress(function (e) {
        if (e.which == 13) {
            fn_obsoletedata($(this).val());
            return false;
        }
    });




});

var lid = $("#hid_lid").val();

function get_hostname(url) {
    var m = url.match(/^http:\/\/[^/]+/);
    return m ? m[0] : null;
}

var pagevariable = {};
var domainname = $('#domainname').val();
pagevariable.imageurl = domainname + 'images/cars/';
pagevariable.pdficonurl = domainname + 'images/model-box-icon1.png';
pagevariable.videoiconeurl = domainname + 'images/model-box-icon2.png';



function imageExists(url, callback) {
    var img = new Image();
    img.onload = function () { callback(true); };
    img.onerror = function () { callback(false); };
    img.src = url;
}

function imageExistsnew(image_url) {

    var http = new XMLHttpRequest();

    http.open('HEAD', image_url, false);
    http.send();

    return http.status != 404;

}

var noimgpath = "";


function fn_runningdata(searchtxt) {

    var objmodel = {};
    objmodel.mstatus = "Y";
    objmodel.lid = lid;
    objmodel.search = searchtxt;
    $.ajax({
        type: "POST",
        url: domainname + "admin/GetModeldashbaord",
        data: JSON.stringify(objmodel),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (response) {
            var dataHtml = '<ul>';
            $.each(response, function (index, item) {
                var str = item.SMAS_MODEL_DESC;
                var Code = item.SMAS_MODEL_CD;
                var Lang_Id = item.LID;
                var flagShow = 'Y'
                str.replace(' ', '');
                var img = pagevariable.imageurl + $.trim(str) + '.png';

                if (item.UserRole == "M") {
                    dataHtml += '<li style="text-align:left;"><a href="#"></i></a><a href="' + domainname + 'admin/Modeldetails/' + item.SMAS_MODEL_CD + '?langugeid=' + lid + '&status=Y"><span><img alt="' + item.SMAS_MODEL_CD + '" title="' + item.SMAS_MODEL_CD + '" src="' + img + '" style="height: 110px;"></span><div class="carFeature"><h3>' + item.SMAS_MODEL_DESC + '</h3><div class="carFeatureIcon">';
                    dataHtml += '<div class="carIcon"><a href="#"><img src="' + pagevariable.pdficonurl + '"></a></div><div class="carIconTxt"><a href="#">' + item.PDF + '</a></div>';
                }
                else {
                    dataHtml += '<li style="text-align:left;"><a href="javascript:void(0)"  onclick="editfile(\'' + str + '\');" data-toggle="modal" class="info"><i class="fa fa-picture-o "></i></a> <a href="#"  onclick="editmodelcode(\'' + Code + '\',\'' + Lang_Id + '\');" data-toggle="modal" class="info"><i class="fa fa-edit"></i></a><a href="' + domainname + 'admin/Modeldetails/' + item.SMAS_MODEL_CD + '?langugeid=' + lid + '&status=Y"><span><img alt="" src="' + img + '" style="height: 110px;"></span><div class="carFeature"><h3>' + item.SMAS_MODEL_DESC + '</h3><div class="carFeatureIcon">';

                    dataHtml += '<div class="carIcon"><a href="#"><img src="' + pagevariable.pdficonurl + '"></a></div><div class="carIconTxt"><a href="#">' + item.PDF + '</a></div>';
                    dataHtml += '<div class="carIcon"><a href="#"><img src="' + pagevariable.videoiconeurl + '"></a></div><div class="carIconTxt"><a href="#">' + item.Video + '</a></div>';
                    dataHtml += '<div class="carIconTxt"><a href="#"  onclick="editmodelcode(\'' + Code + '\',\'' + Lang_Id + '\',\'' + flagShow + '\');"><i class="fa fa-info-circle"></i></a></div>';
                }
                dataHtml += '</div></div></a></li>';
            });
            dataHtml += '</ul>';
            $('#runningdivdata').html(dataHtml);
        },
        failure: function (response) {
            //alert(response.responseText);
        },
        error: function (response) {
            if (response.status && response.status == 400) {
                alert("Something went wrong");
            }
            else if (response.status && response.status == 200) {
                alert("Failing to fecth DMS Response");
            }
            else if (response.status == 0) {
                alert("Please check Internet Connection");
            }
        }
    });
}
function fn_obsoletedata(searchtxt) {


    var objmodel = {};
    objmodel.mstatus = "N";
    objmodel.lid = lid;
    objmodel.search = searchtxt;
    $.ajax({
        type: "POST",
        url: domainname + "admin/GetModeldashbaord",
        data: JSON.stringify(objmodel),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (response) {
            var dataHtml = '<ul>';
            $.each(response, function (index, item) {
                var str = item.SMAS_MODEL_DESC;
                var Code = item.SMAS_MODEL_CD;
                var Lang_Id = item.LID;
                var flagShow = 'Y'
                str.replace(' ', '');

                var img = pagevariable.imageurl + $.trim(str) + '.png';
                if (item.UserRole == "M") {
                    dataHtml += '<li style="text-align:left;"><a href="#"></i></a><a href="' + domainname + 'admin/Modeldetails/' + item.SMAS_MODEL_CD + '?langugeid=' + lid + '&status=N"><span><img alt="' + item.SMAS_MODEL_CD + '" title="' + item.SMAS_MODEL_CD + '" src="' + img + '" style="height: 110px;"></span><div class="carFeature"><h3>' + item.SMAS_MODEL_DESC + '</h3><div class="carFeatureIcon">';

                    dataHtml += '<div class="carIcon"><a href="#"><img src="' + pagevariable.pdficonurl + '"></a></div><div class="carIconTxt"><a href="#">' + item.PDF + '</a></div>';
                }
                else {
                    dataHtml += '<li style="text-align:left;"><a href="javascript:void(0)"  onclick="editfile(\'' + str + '\');" data-toggle="modal" class="info"><i class="fa fa-picture-o"></i></a> <a href="#"  onclick="editmodelcode(\'' + Code + '\',\'' + Lang_Id + '\');" data-toggle="modal" class="info"><i class="fa fa-edit"></i></a><a href="' + domainname + 'admin/Modeldetails/' + item.SMAS_MODEL_CD + '?langugeid=' + lid + '&status=N"><span><img alt="" src="' + img + '" style="height: 110px;"></span><div class="carFeature"><h3>' + item.SMAS_MODEL_DESC + '</h3><div class="carFeatureIcon">';
                    dataHtml += '<div class="carIcon"><a href="#"><img src="' + pagevariable.pdficonurl + '"></a></div><div class="carIconTxt"><a href="#">' + item.PDF + '</a></div>';
                    dataHtml += '<div class="carIcon"><a href="#"><img src="' + pagevariable.videoiconeurl + '"></a></div><div class="carIconTxt"><a href="#">' + item.Video + '</a></div>';
                    dataHtml += '<div class="carIconTxt"><a href="#" alt=""  onclick="editmodelcode(\'' + Code + '\',\'' + Lang_Id + '\',\'' + flagShow + '\');"><i class="fa fa-info-circle"></i></a></div>';
                }
                dataHtml += '</div></div></a></li>';
            });
            dataHtml += '</ul>';
            $('#obsoletedivdata').html(dataHtml);
        },
        failure: function (response) {
            //alert(response.responseText);
        },
        error: function (response) {
            if (response.status && response.status == 400) {
                alert("Something went wrong");
            }
            else if (response.status && response.status == 200) {
                alert("Failing to fecth DMS Response");
            }
            else if (response.status == 0) {
                alert("Please check Internet Connection");
            }
        }
    });
}

function fn_dealers(obj) {
    var objmodel = {};
    objmodel.Regionid = $("#REGION_CD option:selected").val();

    $('#drpDealer').html('');
    $("#drpDealer").append('<option value="" selected="selected">Select Dealer</option>');
    $.ajax({
        type: "POST",
        url: domainname + "admin/GetDealers",
        data: JSON.stringify(objmodel),
        contentType: "application/json; charset=utf-8",
        datatype: "json",
        async: false,
        success: function (response) {

            $.each(response, function (index, item) {
                $("#drpDealer").append('<option value="' + item.WORKSHOP_CD + '"> ' + item.WORKSHOP_NAME + ' (' + item.WORKSHOP_CD + ')</option>');
            });
            //var ss = response;
            //alert(response)

            //var i;
            //for (i = 0; i < response.dealers.items.length; i++) {
            //    $("#drpDealer").append('<option value="' + response.dealers.items[i].WORKSHOP_CD + '"> ' + response.dealers.items[i].WORKSHOP_NAME + '</option>');
            //}
        },
        error: function (response) {
            if (response.status && response.status == 400) {
                alert("Something went wrong");
            }
            else if (response.status && response.status == 200) {
                alert("Failing to fecth DMS Response");
            }
            else if (response.status == 0) {
                alert("Please check Internet Connection");
            }
        }
    });

}


function fn_downloadconsolidatereport() {
    $('#errmsg1').text('');
    var isvalid = true;
    var objdatamodel = {};
    objdatamodel.Fromdate = $('#from2').val();
    objdatamodel.Todate = $('#to2').val();

    if (objdatamodel.Fromdate == "") {
        $('#errmsg1').text('Please select from date.');
        isvalid = false;
        return true;
    }

    if (objdatamodel.Todate == "") {
        $('#errmsg1').text('Please select to date.')
        isvalid = false;
        return true;
    }
    if (objdatamodel.Fromdate != "" && objdatamodel.Todate != "") {
        if (new Date(objdatamodel.Fromdate) > new Date(objdatamodel.Todate)) {
            alert("Start date should be less than End date");
            isvalid = false;
            return true;
        }
        var datediff = new Date(objdatamodel.Todate).getDate() - new Date(objdatamodel.Fromdate).getDate();
        if (datediff > 180) {
            alert("Date Difference should be only 6 months");
            isvalid = false;
            return true;
        }
    }
    if (isvalid) {

        $.ajax({
            type: "POST",
            url: domainname + "admin/DownloadReport",
            data: JSON.stringify(objdatamodel),
            contentType: "application/json; charset=utf-8",
            async: true,
            beforeSend: function () {
                // Show image container
                //$("#loader").show();
                $("#btnconsolidate").text('Please wait...');
                $('.ajax-loader').css("visibility", "visible");
            },

            success: function (response) {
                if (response) {
                    $("#form2").trigger('reset');
                    var mytime = new Date().getTime();
                    var blob = new Blob([response], { type: 'application/ms-excel' });
                    var downloadUrl = URL.createObjectURL(blob);
                    var a = document.createElement("a");
                    a.href = downloadUrl;
                    a.download = "DTSMPUsageReport" + mytime + ".xls";
                    document.body.appendChild(a); a.click();
                }
                else {
                    alert("We have no data found. Please choose another filter data.")
                }


            },
            complete: function (data) {

                $("#btnconsolidate").text('Download Report');
                $('.ajax-loader').css("visibility", "hidden");
                // Hide image container
                //$("#loader").hide();
            },
            error: function (response) {
                if (response.status && response.status == 400) {
                    alert("Something went wrong");
                }
                else if (response.status && response.status == 200) {
                    alert("Failing to fecth DMS Response");
                }
                else if (response.status == 0) {
                    alert("Please check Internet Connection");
                }
            }
        });
    }

}

//added by kritika kulariya
function fn_downloadusagereport() {
    var isvalidate = true;
    region = $("#REGION_CD option:selected").val();
    dealer = $("#drpDealer option:selected").val();

    if (region == '') {
        $('#errre').show();
        isvalidate = false;
        return true;
    } else {
        $('#errre').hide();
        isvalidate = true;
    }

    if (dealer == '') {
        $('#errd').show();
        isvalidate = false;
        return true;
    } else {
        $('#errd').hide();
        isvalidate = true;
    }
    $('#errmanualmsg').text('');

    var objdatamodel = {};
    objdatamodel.DealerName = $("#drpDealer option:selected").text();
    objdatamodel.DealerCode = $("#drpDealer option:selected").val();
    objdatamodel.Fromdate = $('#from').val();
    objdatamodel.Todate = $('#to').val();
    if (objdatamodel.Fromdate != "" && objdatamodel.Todate != "") {
        if (new Date(objdatamodel.Fromdate) > new Date(objdatamodel.Todate)) {
            $('#errmanualmsg').text('Start date should be less than End date');
            isvalidate = false;
            return true;
        }
        var datediff = new Date(objdatamodel.Todate).getDate() - new Date(objdatamodel.Fromdate).getDate();
        if (datediff > 180) {
            $('#errmanualmsg').text('Date Difference should be only 6 months');

            isvalidate = false;
            return true;
        }
    }

    if (isvalidate) {

        $.ajax({
            type: "POST",
            url: domainname + "admin/DownloadExcel",
            data: JSON.stringify(objdatamodel),
            contentType: "application/json; charset=utf-8",
            async: true,
            beforeSend: function () {
                $('.ajax-loader').css("visibility", "visible");

            },
            success: function (response) {
                if (response) {
                    debugger;
                    $("#form3").trigger('reset');
                    document.getElementById("form3").reset();
                    var currentDate = new Date();
                    var day = currentDate.getDate();
                    var month = currentDate.getMonth() + 1;
                    var year = currentDate.getFullYear();
                    var finalDate = day + '-' + month + '-' + year;
                    var blob = new Blob([response], { type: 'application/ms-excel' });
                    var downloadUrl = URL.createObjectURL(blob);
                    var a = document.createElement("a");
                    a.href = downloadUrl;
                    a.download = "ConsolidateUsageReport" + finalDate + ".xls";
                   
                    document.body.appendChild(a); a.click();
                }
                else {
                    alert("We have no data found. Please choose another dealer or filter data.")
                    $("#form3").trigger('reset');
                    document.getElementById("form3").reset();
                }

                //$.each(response, function (index, item) {
                //    $("#drpDealer").append('<option value="' + item.WORKSHOP_CD + '"> ' + item.WORKSHOP_NAME + '</option>');
                //});
                //var ss = response;
                //alert(response)

                //var i;
                //for (i = 0; i < response.dealers.items.length; i++) {
                //    $("#drpDealer").append('<option value="' + response.dealers.items[i].WORKSHOP_CD + '"> ' + response.dealers.items[i].WORKSHOP_NAME + '</option>');
                //}
            },
            complete: function (data) {
                $('.ajax-loader').css("visibility", "hidden");

            },
            error: function (response) {
                if (response.status && response.status == 400) {
                    alert("Something went wrong");
                }
                else if (response.status && response.status == 200) {
                    alert("Failing to fecth DMS Response");
                }
                else if (response.status == 0) {
                    alert("Please check Internet Connection");
                }
            }
        });
    }
}
function datedifference(date1, date2) {
    // Create a new Date object representing the first date
    dt1 = new Date(date1);
    // Create a new Date object representing the second date
    dt2 = new Date(date2);
    // Calculate the difference in days between the two dates
    return Math.floor((Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) - Date.UTC(dt1.getFullYear(), dt1.getMonth(), dt1.getDate())) / (1000 * 60 * 60 * 24));
}
function fn_downloadmtnlreport() {
    var objdatamodel = {};
    $('#errmtnlmsg').text('');
    var isvalid = true;
    objdatamodel.Fromdate = $('#from3').val();
    objdatamodel.Todate = $('#to3').val();

    if (objdatamodel.Fromdate == "") {
        $('#errmtnlmsg').text('Please select from date.');
        isvalid = false;
        return true;
    }

    if (objdatamodel.Todate == "") {
        $('#errmtnlmsg').text('Please select to date.')
        isvalid = false;
        return true;
    }
    if (objdatamodel.Fromdate != "" && objdatamodel.Todate != "") {
        if (new Date(objdatamodel.Fromdate) > new Date(objdatamodel.Todate)) {
            $('#errmtnlmsg').text('Start date should be less than End date');
            isvalid = false;
            return true;
        }
        //var datediff = new Date(objdatamodel.Todate).getDate() - new Date(objdatamodel.Fromdate).getDate();
        var datediff = datedifference(objdatamodel.Fromdate, objdatamodel.Todate)
        if (datediff > 180) {
            $('#errmtnlmsg').text('Date Difference should be only 6 months');
            isvalid = false;
            return true;
        }
    }

    if (isvalid) {

        $.ajax({
            type: "POST",
            url: domainname + "admin/DownloadMTNLReport",
            data: JSON.stringify(objdatamodel),
            contentType: "application/json; charset=utf-8",
            async: true,
            beforeSend: function () {
                $('.ajax-loader').css("visibility", "visible");

            },

            success: function (response) {
                if (response) {
                    $("#form4").trigger('reset');
                    var currentDate = new Date();
                    var day = currentDate.getDate();
                    var month = currentDate.getMonth() + 1;
                    var year = currentDate.getFullYear();
                    var finalDate = day + '-' + month + '-' + year;
                    var blob = new Blob([response], { type: 'application/ms-excel' });
                    var downloadUrl = URL.createObjectURL(blob);
                    var a = document.createElement("a");
                    a.href = downloadUrl;
                    a.download = "MTNL_UsageReport" + finalDate + ".xls";
                    document.body.appendChild(a); a.click();
                }
                else {
                    alert("We have no data found. Please choose another dealer or filter data.")
                }

            },
            complete: function (data) {
                $('.ajax-loader').css("visibility", "hidden");

            },
            error: function (response) {
                if (response.status && response.status == 400) {
                    alert("Something went wrong");
                }
                else if (response.status && response.status == 200) {
                    alert("Failing to fecth DMS Response");
                }
                else if (response.status == 0) {
                    alert("Please check Internet Connection");
                }
            }
        });
    }
}
function fn_downloadusagedetailsreport() {

    $('#errmsg').text('');
    var isvalid = true;
    var objdatamodel = {};
    objdatamodel.Fromdate = $('#from4').val();
    objdatamodel.Todate = $('#to4').val();

    if (objdatamodel.Fromdate == "") {
        $('#errmsg').text('Please select from date.');
        isvalid = false;
        return true;
    }

    if (objdatamodel.Todate == "") {
        $('#errmsg').text('Please select to date.')
        isvalid = false;
        return true;
    }
    if (objdatamodel.Fromdate != "" && objdatamodel.Todate != "") {
        if (new Date(objdatamodel.Fromdate) > new Date(objdatamodel.Todate)) {
            $('#errmsg').text('Start date should be less than End date');
            isvalid = false;
            return true;
        }
        var datediff = datedifference(objdatamodel.Fromdate, objdatamodel.Todate)
        // var datediff = new Date(objdatamodel.Todate).getDate() - new Date(objdatamodel.Fromdate).getDate();
        if (datediff > 180) {
            $('#errmsg').text('Date Difference should not be more then 6 months');
            isvalid = false;
            return true;
        }
    }
    if (isvalid) {
        $.ajax({
            type: "POST",
            url: domainname + "admin/DownloadUsageReport",
            data: JSON.stringify(objdatamodel),
            contentType: "application/json; charset=utf-8",
            async: true,
            beforeSend: function () {
                $('.ajax-loader').css("visibility", "visible");
                $("#btnnew").text('Please wait...');
            },

            success: function (response) {

                if (response) {
                    var form = document.getElementById("form1");
                    form.reset();
                    var currentDate = new Date();
                    var day = currentDate.getDate();
                    var month = currentDate.getMonth() + 1;
                    var year = currentDate.getFullYear();
                    var finalDate = day + '-' + month + '-' + year;
                    var blob = new Blob([response], { type: 'application/ms-excel' });
                    var downloadUrl = URL.createObjectURL(blob);
                    var a = document.createElement("a");
                    a.href = downloadUrl;
                    a.download = "SerManualUsageReport" + finalDate + ".xls";
                    document.body.appendChild(a); a.click();
                }
                else {
                    alert("We have no data found. Please choose another filter data.")
                }


            },
            complete: function (data) {
                $('.ajax-loader').css("visibility", "hidden");
                $("#btnnew").text('Download Report');
            },
            error: function (response) {
                if (response.status && response.status == 400) {
                    alert("Something went wrong");
                }
                else if (response.status && response.status == 200) {
                    alert("Failing to fecth DMS Response");
                }
                else if (response.status == 0) {
                    alert("Please check Internet Connection");
                }
            }
        });
    }

}

